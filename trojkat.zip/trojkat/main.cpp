#include <iostream>
#include <math.h>
#include <string>

using namespace std;

struct Wsp {
	double x;
	double y;
};

class Trojkat {
	public:
		Trojkat(
		    struct Wsp &WspA,
		    struct Wsp &WspB,
		    struct Wsp &WspC
		);// Tutaj podamy wspolrzedne i utworzymy trojkat
		// wyjqtki, zle wspolrzedne, ujemny wynik out,
		double obliczBok(struct Wsp X, struct Wsp Y) {
			return sqrt(pow(X.x-Y.x,2) + pow(X.y-Y.y,2)); // obliczanie dlugosci boku z podanych wspolrzednych
		}
		int zweryfikuj(struct Wsp WspA, struct Wsp WspB, struct Wsp WspC); // sprawdzimy jaki trojkat wychodzi z podanych przez uzytkowika danych
		//oraz czy wogole jest to trojkat czy odcinek lub punkt
		bool czyPunkt(struct Wsp WspA, struct Wsp WspB, struct Wsp WspC); // sprawdzenie oraz zwrocenie czy z podanych wsporlzednych wychodzi punkt
		double setPrzeciwProstokatna(double bokAB, double bokBC, double bokCA);
		int wynikWeryfikacji() {
			return jakiTrojkat;
		}
		void wyswietlDlugoscBokow() {
			cout << "Odcinek AB: " << bokAB << endl;
			cout << "Odcinek BC: " << bokBC << endl;
			cout << "Odcinek CA: " << bokCA << endl;
		}
		void wyswietlWspolrzedne(struct Wsp WspA, struct Wsp WspB, struct Wsp WspC) {
			cout << "Wspolrzedne trojkata" << endl;
			cout << "x1: " << WspA.x << " y1: " << WspA.y << endl;
			cout << "x2: " << WspB.x << " y2: " << WspB.y << endl;
			cout << "x3: " << WspC.x << " y3: " << WspB.y << endl;
		}
	protected:
		double bokAB, bokBC, bokCA;
		int jakiTrojkat;
		double przeciwP;
};

Trojkat::Trojkat(struct Wsp &WspA, struct Wsp &WspB, struct Wsp &WspC) {
	
	bokAB = obliczBok(WspA, WspB);
	bokBC = obliczBok(WspB, WspC);
	bokCA = obliczBok(WspC, WspA);

	jakiTrojkat = zweryfikuj(WspA, WspB, WspC);
}

int Trojkat::zweryfikuj(struct Wsp WspA, struct Wsp WspB, struct Wsp WspC) {
	
	double AB = pow(bokAB, 2);
	double BC = pow(bokBC, 2);
	double CA = pow(bokCA, 2);
	if(czyPunkt(WspA, WspB, WspC)) {
		return 1;
	} else if(bokAB == bokBC && bokAB == bokCA)
		// trojkat rownoboczny
		return 2;
	else if(bokAB == bokBC || bokAB == bokCA  || bokCA == bokBC)
		// trojkat rownoramienny
		return 3;
	else if(AB == (BC + CA) || BC == (AB + CA) || CA == (AB + BC)) {
		// trojkat prostokatny
		przeciwP = setPrzeciwProstokatna(AB, BC, CA);
		return 4;
	}
}

bool Trojkat::czyPunkt(struct Wsp WspA, struct Wsp WspB, struct Wsp WspC) {
	if(WspA.x == WspB.x && WspB.x == WspC.x && WspA.y == WspB.y && WspB.y == WspC.y)
		return true;
	else
		return false;
}

double Trojkat::setPrzeciwProstokatna(double AB, double BC, double CA) {	
	if((AB + BC) == CA)
		return sqrt(CA);
	else if((AB + CA) == BC)
		return sqrt(BC);
	else if((BC + CA) == AB)
		return sqrt(AB);
}

class TrojkatRownoboczny:public Trojkat {
	public:
		TrojkatRownoboczny(
		    struct Wsp &WspA,
		    struct Wsp &WspB,
		    struct Wsp &WspC
		):Trojkat(
			    WspA,
			    WspB,
			    WspC
			) {
			h = obliczH(bokAB);
			obwod = obliczObwod(bokAB);
			pole = obliczPole(bokAB);
			Trojkat::wyswietlWspolrzedne(WspA, WspB, WspC);
		};
		void wyswietlTrojkat() {
			cout << "Trojkat rownoboczny " << endl;
			Trojkat::wyswietlDlugoscBokow();
			cout << "Wysokosc wynosi: " << h << endl;
			cout << "Obwod wynosi: " << obwod << endl;
			cout << "Pole wynosi: " << pole << endl;
		}
	private:
		double h;
		double obwod;
		double pole;

		// tutaj obliczamy obwod, miary katow, pole,
		// obwod: bokA + bokB + bokC
		// pole a^2 * sqrt(3) / 4
		
		double obliczH(double bokAB) {
			return (sqrt(3)*bokAB)/2;
		}
		double obliczObwod(double bokAB) {
			return bokAB*3;
		}
		double obliczPole(double bokAB) {
			return (pow(bokAB, 2)*sqrt(3))/4;
		}
};

class TrojkatProstokatny:public Trojkat {
	public:
		TrojkatProstokatny(
		    struct Wsp &WspA,
		    struct Wsp &WspB,
		    struct Wsp &WspC
		):Trojkat(WspA, WspB, WspC) {

			if(przeciwP == bokAB){
				h1 = bokBC;
				h2 = bokCA;
				pole = obliczPole(bokAB, h1);
			}
			else if(przeciwP == bokBC){
				h1 = bokAB;
				h2 = bokCA;
				pole = obliczPole(bokAB, h1);
			}
			else if(przeciwP == bokCA){
				h1 = bokAB;
				h2 = bokBC;
				pole = obliczPole(bokAB, h1);
			}
			obwod = obliczObwod(bokAB, bokBC, bokCA);
			Trojkat::wyswietlWspolrzedne(WspA, WspB, WspC);
		};
		void wyswietlTrojkat() {
			cout << "Trojkat prostokatny " << endl;
			Trojkat::wyswietlDlugoscBokow();
			cout << "Wysokosc wynosi: " << h1 << " lub " << h2 << endl;
			cout << "Obwod wynosi: " << obwod << endl;
			cout << "Pole wynosi: " << pole << endl;
			cout << "Przeciwprostokatna: " << przeciwP << endl;
		}
	private:
		double h1, h2;
		double pole;
		double obwod;

		double obliczPole(double a, double h) {
			return (a*h)/2;
		}
		double obliczObwod(double A, double B, double C) {
			return A + B + C;
		}
};

class TrojkatRownoramienny:public Trojkat {
	public:
		TrojkatRownoramienny(
		    struct Wsp &WspA,
		    struct Wsp &WspB,
		    struct Wsp &WspC
		):Trojkat(
			    WspA,
			    WspB,
			    WspC
			) {
			if(bokAB == bokBC) {
				h = obliczH(bokCA,bokAB);
				pole = obliczPole(bokCA, h);
			} else if(bokAB == bokCA) {
				h = obliczH(bokBC, bokAB);
				pole = obliczPole(bokBC, h);
			} else if(bokCA == bokBC) {
				h = obliczH(bokAB, bokBC);
				pole = obliczPole(bokAB, h);
			}
			obwod = obliczObwod(bokAB, bokBC, bokCA);
			Trojkat::wyswietlWspolrzedne(WspA, WspB, WspC);
		};
		void wyswietlTrojkat() {
			cout << "Trojkat rownoramienny " << endl;
			Trojkat::wyswietlDlugoscBokow();
			cout << "Wysokosc wynosi: " << h << endl;
			cout << "Obwod wynosi: " << obwod << endl;
			cout << "Pole wynosi: " << pole << endl;
		}
	private:
		double obliczH(double a, double b) {
			h = pow(b/2, 2) + pow(a, 2);
			return sqrt(h);
		}
		double obliczObwod(double AB, double BC, double CA) {
			return AB + BC + CA;
		}
		double obliczPole(double a, double h) {
			return a/2 * h;
		}
		double obwod, pole, h;
		// Tutaj obliczamy obwod, miary katow, pole,
		// obwod: bokA + bokB + bokC
		// pole a * h / 2
		// katy: obliczamy h, podstawa podzielona przez 2 i pitagoras
};

class DowolnyTrojkat:public Trojkat{
	public:
		DowolnyTrojkat(
		    struct Wsp &WspA,
		    struct Wsp &WspB,
		    struct Wsp &WspC
		):Trojkat(
			    WspA,
			    WspB,
			    WspC
			) {
			obwod = obliczObwod(bokAB, bokBC, bokCA);
			pole = obliczPole(obwod/2, bokAB, bokBC, bokCA);
		};
		void wyswietlTrojkat() {
			cout << "Dowolny trojkat" << endl;
			Trojkat::wyswietlDlugoscBokow();
			cout << "Obwod wynosi: " << obwod << endl;
			cout << "Pole wynosi: " << pole << endl;
		}
	private:
		double obwod;
		double pole;
		
		double obliczObwod(double bokAB, double bokBC, double bokCA){
			return bokAB + bokBC + bokCA;
		}
		double obliczPole(double p, double a, double b, double c){
			return sqrt(p * (p - a) * (p - b) * (p - c));
		}
};

Wsp WspA;
Wsp WspB;
Wsp WspC;

void pobierzDane() {

	cout << "Podaj wspolrzedne punktu A" << endl;
	cout << "x1: ";
	cin >> WspA.x;
	cout << "y1: ";
	cin >> WspA.y;

	cout << "Podaj wspolrzedne punktu B" << endl;
	cout << "x2: ";
	cin >> WspB.x;
	cout << "y2: ";
	cin >> WspB.y;

	cout << "Podaj wspolrzedne punktu C" << endl;
	cout << "x3: ";
	cin >> WspC.x;
	cout << "y3: ";
	cin >> WspC.y;

}

int main(int argc, char** argv) {

	pobierzDane();

	Trojkat Trojkat(WspA, WspB, WspC);

	int jakiTrojkat = Trojkat.wynikWeryfikacji();

	switch(jakiTrojkat) {
		case 1: {
			cout << "Z podanych wspolrzednych wychodzi punkt" << endl;
			cout << "Wspolrzedne punktu " << endl;
			cout << "x: " << WspA.x << endl;
			cout << "y: " << WspA.y << endl;
			break;
		}
		case 2: {
			TrojkatRownoboczny TrojkatRownoboczny(WspA, WspB, WspC);
			TrojkatRownoboczny.wyswietlTrojkat();
			break;
		}
		case 3: {
			TrojkatRownoramienny TrojkatRownoramienny(WspA, WspB, WspC);
			TrojkatRownoramienny.wyswietlTrojkat();
			break;
		}
		case 4: {
			TrojkatProstokatny TrojkatProstokatny(WspA, WspB, WspC);
			TrojkatProstokatny.wyswietlTrojkat();
			break;
		}
		default: {
			//Trojkat dowolny, nie pasuje do �adnych powy�szych kryteri�w
			DowolnyTrojkat DowolnyTrojkat(WspA, WspB, WspC);
			DowolnyTrojkat.	wyswietlTrojkat();
		}
			
	}

	system("PAUSE");
	return 0;
}
