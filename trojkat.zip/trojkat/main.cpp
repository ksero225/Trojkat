#include <iostream>
#include <math.h>
#include <string>

using namespace std;

struct Wspolrzedne{
	double x,y;
};

class Trojkat{
	public: 
		Trojkat(
			double x1, 
			double y1, 
			double x2, 
			double y2, 
			double x3, 
			double y3
		); // Tutaj podamy wspolrzedne i utworzymy trojkat
		// wyjqtki, zle wspolrzedne, ujemny out,  
		bool zweryfikuj(
			A.x,A.y,
			B.x,B.y,
			C.x,C.y	
		); // sprawdzimy czy wybrany trojkat jest ok
		double obliczBok(double x1, double x2, double y1, double y2){
			return sqrt(pow(x2-x1,2) + pow(y2-y1,2));
		}
	protected:
		Wspolrzedne A;
		Wspolrzedne B;
		Wspolrzedne C;
		double bokA,bokB,bokC;
};

Trojkat::Trojkat(double x1, double y1, double x2, double y2, double x3, double y3){
	A.x = x1;
	A.y = y1;
	B.x = x2;
	B.y = y2;
	C.x = x3;
	C.y = y3;
}

Trojkat::zweryfikuj(double x1, double y1, double x2, double y2, double x3, double y3){
	bokA = obliczBok(x1,x2,y1,y2);
	bokB = obliczBok(x2,x3,y2,y3);
	bokC = obliczBok(x3,x1,y3,y1);
	if(bokA <= 0 || bokB <= 0 || bokC <=0){
		// trojkat nie istnieje
	}
	else if()
}

class TrojkatProstokatny:public Trojkat{
	public:
		
	private:
		// tutaj obliczamy obwod, miary katow, pole, obwod
		// obwod: bokA + bokB + bokC
		// pole a * h / 2
		// katy sin tg ctg cos
		double poleProstokatny(){
			
		}
		double obwodProstokatny(double A, double B, double C){
			return A + B + C;
		}
};

class TrojkatRownoramienny:public Trojkat{
	public:
		
	private:
		// Tutaj obliczamy obwod, miary katow, pole,
		// obwod: bokA + bokB + bokC
		// pole a * h / 2
		// katy: obliczamy h, podstawa podzielona przez 2 i pitagoras
};

class TrojkatRownoboczny:public Trojkat{
	public:
		
	private:
		// tutaj obliczamy obwod, miary katow, pole,
		// obwod: bokA + bokB + bokC
		// pole a^2 * sqrt(3) / 4
};

int main(int argc, char** argv) {
	
	Wspolrzedne A;
	Wspolrzedne B;
	Wspolrzedne C;
	
	A.x = 2;
	A.y = 3;
	
	B.x = 4;
	B.y = 5;
	
	C.x = 6;
	C.y = 7;
	
	Trojkat Trojkat(
	A.x,A.y,
	B.x,B.y,
	C.x,C.y
	);
	
	system("PAUSE");
	return 0;
}
