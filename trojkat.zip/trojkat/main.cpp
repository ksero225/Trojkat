#include <iostream>
#include <math.h>
#include <string>

using namespace std;

struct Wsp {
	double x;
	double y;
};

class Trojkat {

	public:
		Trojkat(
		    struct Wsp &WspA,
		    struct Wsp &WspB,
		    struct Wsp &WspC
		);// Tutaj podamy wspolrzedne i utworzymy trojkat
		// wyjqtki, zle wspolrzedne, ujemny out,
		double obliczBok(struct Wsp X, struct Wsp Y) {
			return sqrt(pow(X.x-Y.x,2) + pow(X.y-Y.y,2));
		}

		int zweryfikuj(double bokA, double bokB, double bokC); // sprawdzimy jaki trojkat wychodzi z podanych przez uzytkowika danych
		//oraz czy wogole jest to trojkat, lub
		
		int czyOdcinek(struct Wsp WspA, struct Wsp WspB, struct Wsp WspC);
		
		int wynikWeryfikacji() {
			return jakiTrojkat;
		}

		void wyswietlDlugoscBokow() {
			cout << "Odcinek AB: " << bokA << endl;
			cout << "Odcinek BC: " << bokB << endl;
			cout << "Odcinek CA: " << bokC << endl;
		}
	protected:
		double bokA,bokB,bokC;
		int jakiTrojkat;
};

Trojkat::Trojkat(struct Wsp &WspA, struct Wsp &WspB, struct Wsp &WspC) {
	bokA = obliczBok(WspA, WspB);
	bokB = obliczBok(WspB, WspC);
	bokC = obliczBok(WspC, WspA);

	if(czyOdcinek(WspA, WspB, WspC))
		jakiTrojkat = 6;
	else
		jakiTrojkat = zweryfikuj(bokA, bokB, bokC);
}

Trojkat::czyOdcinek(struct Wsp WspA, struct Wsp WspB, struct Wsp WspC){
	if(WspA.x == WspB.x && WspB.x == WspC.x && WspA.y == WspB.y && WspB.y == WspC.y)
		//punkt
		return true;
	else
		return false;
}

Trojkat::zweryfikuj(double bokA, double bokB, double bokC) {
	if(bokA == bokB && bokA == bokC)
		// trojkat rownoboczny
		return 1;
	else if(bokA == bokB || bokA == bokC  || bokC == bokB) 
		// trojkat rownoramienny
		return 2;
	else if(pow(bokA + bokB, 2) == pow(bokC,2))
		// trojkat prostokatny
		return 3;
//	else if()
//		// trojkat
//		return 4;
//	else if()
//		//odcinek
//		return 5;
//	else if()
//		//punkt
//		return 6;
}

class TrojkatRownoboczny:public Trojkat {
	public:
		TrojkatRownoboczny(
		    struct Wsp &WspA,
		    struct Wsp &WspB,
		    struct Wsp &WspC
		):Trojkat(
			    WspA,
			    WspB,
			    WspC
			) {
			h = obliczH(bokA);
			obwod = obliczObwod(bokA);
			pole = obliczPole(bokA);
		};
		// tutaj obliczamy obwod, miary katow, pole,
		// obwod: bokA + bokB + bokC
		// pole a^2 * sqrt(3) / 4

		void wyswietlTrojkat() {
			cout << "Trojkat rownoboczny " << endl;
			Trojkat::wyswietlDlugoscBokow();
			cout << "Wysokosc wynosi: " << h << endl;
			cout << "Obwod wynosi: " << obwod << endl;
			cout << "Pole wynosi: " << pole << endl;
		}

	private:
		double h;
		double obwod;
		double pole;

		double obliczH(double bokA) {
			return (sqrt(3)*bokA)/2;
		}
		double obliczObwod(double bokA) {
			return bokA*3;
		}
		double obliczPole(double bokA) {
			return (pow(bokA, 2)*sqrt(3))/4;
		}
};

class TrojkatProstokatny:public Trojkat {
	public:
		// tutaj obliczamy obwod, miary katow, pole, obwod
		// obwod: bokA + bokB + bokC
		// pole a * h / 2
		// katy sin tg ctg cos
		double poleProstokatny() {

		}
		double obwodProstokatny(double A, double B, double C) {
			return A + B + C;
		}
};

class TrojkatRownoramienny:public Trojkat {
	public:
		TrojkatRownoramienny(
		    struct Wsp &WspA,
		    struct Wsp &WspB,
		    struct Wsp &WspC
		):Trojkat(
			    WspA,
			    WspB,
			    WspC
			) {
			if(bokA == bokB) {
				obliczH(bokC,bokA);
				obliczPole(bokC, h);
			} else if(bokA == bokC) {
				obliczH(bokB, bokA);
				obliczPole(bokB, h);
			} else if(bokC == bokB) {
				obliczH(bokA, bokB);
				obliczPole(bokA, h);
			}

			obliczObwod(bokA, bokB, bokC);
		};
		void wyswietlTrojkat() {
			cout << "Trojkat rownoramienny " << endl;
			Trojkat::wyswietlDlugoscBokow();
			cout << "Wysokosc wynosi: " << h << endl;
			cout << "Obwod wynosi: " << obwod << endl;
			cout << "Pole wynosi: " << pole << endl;
		}
	private:
		double obliczH(double a, double b) {
			h = pow(b/2, 2) + pow(a, 2);
			h = sqrt(h);
		}
		double obliczObwod(double AB, double BC, double CA) {
			obwod = AB + BC + CA;
		}
		double obliczPole(double a, double h) {
			pole = a/2 * h;
		}
		
		double obwod, pole, h;
		// Tutaj obliczamy obwod, miary katow, pole,
		// obwod: bokA + bokB + bokC
		// pole a * h / 2
		// katy: obliczamy h, podstawa podzielona przez 2 i pitagoras
};

Wsp WspA;
Wsp WspB;
Wsp WspC;

void pobierzDane(){
	
	cout << "Podaj wspolrzedne punktu A" << endl;
	cout << "x1: ";
	cin >> WspA.x;
	cout << "y1: ";
	cin >> WspA.y;
	
	cout << "Podaj wspolrzedne punktu B" << endl;
	cout << "x2: ";
	cin >> WspB.x;
	cout << "y2: ";
	cin >> WspB.y;
	
	cout << "Podaj wspolrzedne punktu C" << endl;
	cout << "x3: ";
	cin >> WspC.x;
	cout << "y3: ";
	cin >> WspC.y;
	
}

int main(int argc, char** argv) {
	
	pobierzDane();

	Trojkat Trojkat(WspA, WspB, WspC);

	int jakiTrojkat = Trojkat.wynikWeryfikacji();

	switch(jakiTrojkat) {
		case 1: {
			//Trojkat rownoboczny
			TrojkatRownoboczny TrojkatRownoboczny(WspA, WspB, WspC);
			TrojkatRownoboczny.wyswietlTrojkat(); // wyswietlenie obwodu, pola
			break;
		}
		case 2: {
			//Trojkat rownoramienny
			TrojkatRownoramienny TrojkatRownoramienny(WspA, WspB, WspC);
			TrojkatRownoramienny.wyswietlTrojkat();
			break;
		}
		case 3:
			//Trojkat prostokatny
			cout << "Trojkat prostokatny " << endl;
			Trojkat.wyswietlDlugoscBokow();
			break;
		case 4: {
			//Z podanych wspolrzednych wychodzi odcinek, linia
			cout << "Odcinek ";
			break;
		}
		case 6: {
			//z podanych wspolrzednych wychodzi punkt
			cout << "Z podanych wspolrzednych wychodzi punkt" << endl;
			cout << "Wspolrzedne punktu " << endl;
			cout << "x: " << WspA.x << endl;
			cout << "y: " << WspA.y << endl;
			break;
		}
		default:
			//Trojkat zwyk�y, nie pasuje do �adnych powy�szych kryteri�w
			//Pole z wzoru herona, obwod, wyswietlic wspolrzedne
			cout << "default";
	}

	system("PAUSE");
	return 0;
}
